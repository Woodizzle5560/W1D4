class Simon
  COLORS = %w(red blue green yellow)

  attr_accessor :sequence_length, :game_over, :seq

  def initialize
    self.sequence_length = 1
    self.game_over = false
    self.seq = []
  end

  def play
    until game_over
      self.take_turn
    end

    if !game_over
      self.game_over_message
      self.reset_game
    end

  end

  def take_turn
    self.show_sequence
    self.require_sequence

    if self.game_over == false
      self.round_success_message
      self.sequence_length += 1
    end

  end

  def show_sequence
    self.add_random_color
  end

  def require_sequence
    input = gets.chomp
    if input != self.seq
      self.game_over_message
      game_over_message = true
    else
      self.round_success_message
      game_over_message = false
    end

  end

  def add_random_color
    colors = ["red","blue","yellow","green"]
    rand_col = colors[rand(0...colors.length)]
    self.seq << rand_col
  end

  def round_success_message
    puts 'success, you remembered everything!'
  end

  def game_over_message
    puts "game over!"
  end

  def reset_game
    self.sequence_length = 1
    self.game_over_message = false
    self.seq = []
  end
end
