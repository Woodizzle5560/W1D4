class Board
  attr_accessor :cups

  def initialize(name1, name2)
    @cups = Array.new(12) {nil}
    @cups.push(nil)
    @cups.unshift(nil)
  end

  def [](pos)
    @cups[pos]
  end

  def []=(pos, stone)
    if self[pos].nil?
      @cups[pos] = [stone]
    else 
      @cups[pos] << stone
    end
  end

  def valid_move?(start_pos)
   raise('Invalid starting cup') if start_pos < 0 || > 14
   raise('Starting cup is empty') if self[start_pos].nil?
   true
  end

  def make_move(start_pos, current_player_name)
    if valid_move?(start_pos)
      num_stones = self[start_pos].length
      (start_pos..num_stones).each do |i|
        next_cup = (i % @cups.length)
        next if current_player_name == name1 && i == 0
        next if current_player_name == name2 && i == 14
        self[ next_cup ] = 1
      end

      self.render
    end
  end

  def next_turn(ending_cup_idx)
    # helper method to determine whether #make_move returns :switch, :prompt, or ending_cup_idx
   if ending_cup_idx == 0 && current_player_name == name1
      self.prompt
   elsif ending_cup_idx == 14 && current_player_name == name2
      self.prompt
   elsif self[ending_cup_idx] > 0
      return ending_cup_idx
   end

  end

  def render
    print "      #{@cups[7..12].reverse.map { |cup| cup.count }}      \n"
    puts "#{@cups[13].count} -------------------------- #{@cups[6].count}"
    print "      #{@cups.take(6).map { |cup| cup.count }}      \n"
    puts ""
    puts ""
  end

  def one_side_empty?
    return false if !(self[0].nil? && self[14].nil?)
    return true if (self[0].nil? || self[14].nil?)
  end

  def winner
    return name1 if self[0] > 6
    return name2 if self[14] > 6
  end
end
